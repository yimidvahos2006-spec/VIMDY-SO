export const APP_URL = import.meta.env.VITE_APP_URL || "https://app.vimdy.co";
