import { useEffect, useState, type FormEvent } from "react";
import { Loader2, Package } from "lucide-react";

import { VimdyCard } from "../ui/VimdyCard";
import { VimdyButton } from "../ui/VimdyButton";
import { VimdyInput } from "../ui/VimdyInput";
import { VimdySelect } from "../ui/VimdySelect";
import { container } from "../../../infrastructure/di/CompositionRoot";
import { useAuth } from "../../context/AuthContext";
import { translateBusinessError } from "../../../core/errors/translateBusinessError";
import { parseMoneyInput } from "../../../core/utils/parseMoneyInput";
import type { Category } from "../../../core/entities/Entities";

interface FirstProductStepProps {
  categories: Category[];
  onSaved: () => void;
}

export function FirstProductStep({ categories, onSaved }: FirstProductStepProps) {
  const { user } = useAuth();

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [cost, setCost] = useState("");
  const [stock, setStock] = useState("");
  const [categoryId, setCategoryId] = useState(categories[0]?.id ?? (categories.length === 0 ? "uncategorized" : ""));
  const [saving, setSaving] = useState(false);
  const [checkingProducts, setCheckingProducts] = useState(true);
  const [hasActiveProduct, setHasActiveProduct] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;

    void container.inventoryEngine.get().listAll()
      .then((products) => {
        if (mounted) setHasActiveProduct(products.some((product) => product.active !== false));
      })
      .catch(() => {
        if (mounted) setError("No se pudo comprobar el inventario. Intenta de nuevo.");
      })
      .finally(() => {
        if (mounted) setCheckingProducts(false);
      });

    return () => {
      mounted = false;
    };
  }, []);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (saving) return;

    const priceValue = parseMoneyInput(price);
    const stockValue = Number(stock);
    const costValue = cost.trim() ? parseMoneyInput(cost) : undefined;

    if (!name.trim()) {
      setError("El nombre del producto es obligatorio.");
      return;
    }
    if (!categoryId) {
      setError("Elige una categoría.");
      return;
    }
    if (Number.isNaN(priceValue) || priceValue < 0) {
      setError("El precio debe ser un número válido.");
      return;
    }
    if (Number.isNaN(stockValue) || stockValue < 0) {
      setError("El stock debe ser un número válido.");
      return;
    }
    if (costValue !== undefined && (Number.isNaN(costValue) || costValue < 0)) {
      setError("El costo debe ser un número válido.");
      return;
    }

    setSaving(true);
    setError(null);

    try {
      // Si no hay categorías (se omitió el paso 5) NO se guarda el id falso
      // "uncategorized": se usa (o se crea) una categoría real "General".
      let finalCategoryId = categoryId;
      if (finalCategoryId === "uncategorized") {
        const engine = container.categoryEngine.get();
        const all = await engine.listAll();
        const general =
          all.find((c) => c.name.trim().toLowerCase() === "general") ??
          (await engine.create({ name: "General" }));
        finalCategoryId = general.id;
      }

      await container.inventoryEngine.get().createProduct(
        {
          name: name.trim(),
          categoryId: finalCategoryId,
          price: priceValue,
          stock: stockValue,
          minStock: 0,
          purchasePrice: costValue
        },
        user?.id
      );
      setHasActiveProduct(true);
      onSaved();
    } catch (err) {
      const message = translateBusinessError(err, "No se pudo crear el producto.");
      setError(message);
    } finally {
      setSaving(false);
    }
  }

  async function handleContinue() {
    if (saving || checkingProducts) return;

    try {
      const products = await container.inventoryEngine.get().listAll();
      if (!products.some((product) => product.active !== false)) {
        setError("Crea al menos un producto activo antes de continuar.");
        return;
      }
      setHasActiveProduct(true);
      onSaved();
    } catch {
      setError("No se pudo comprobar el inventario. Intenta de nuevo.");
    }
  }

  return (
    <div className="w-full max-w-3xl mx-auto">
      <div className="text-center mb-10">
        <p className="text-vimdy-micro uppercase tracking-widest text-vimdy-accent font-semibold mb-3">Paso 6 de 7</p>
        <h2 className="text-vimdy-h2 text-vimdy-text mb-2">Agrega tu primer producto o servicio</h2>
        <p className="text-vimdy-small text-vimdy-text-secondary max-w-md mx-auto">
          Así podrás comenzar a registrar ventas apenas termines la configuración.
        </p>
      </div>

      <VimdyCard padding="lg" className="w-full max-w-xl mx-auto">
        <form onSubmit={handleSubmit} className="flex flex-col gap-5">
          <div className="flex items-center gap-3 rounded-vimdy-md border-2 border-vimdy-border bg-vimdy-surface p-4">
            <div className="w-10 h-10 rounded-vimdy-md bg-vimdy-background text-vimdy-text-secondary flex items-center justify-center shrink-0">
              <Package size={20} strokeWidth={1.8} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold text-vimdy-text">Producto o servicio</p>
              <p className="text-xs text-vimdy-text-muted mt-0.5">Completa los datos básicos para comenzar.</p>
            </div>
          </div>

          <VimdyInput
            label="Nombre del producto o servicio *"
            placeholder="Ej. Hamburguesa Clásica, Café Americano, Camiseta, Corte de cabello..."
            value={name}
            onChange={(e) => setName(e.target.value)}
            disabled={saving}
          />

          <VimdySelect
            label="Categoría *"
            value={categoryId}
            onChange={(e) => setCategoryId(e.target.value)}
            disabled={saving}
          >
            {categories.length === 0 && <option value="uncategorized">Sin categoría</option>}
            {categories.map((category) => (
              <option key={category.id} value={category.id}>
                {category.name}
              </option>
            ))}
          </VimdySelect>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <VimdyInput
              type="text"
              inputMode="decimal"
              label="Precio de venta *"
              placeholder="0"
              value={price}
              onChange={(e) => setPrice(e.target.value)}
              disabled={saving}
            />
            <VimdyInput
              type="text"
              inputMode="decimal"
              label="Costo (opcional)"
              placeholder="0"
              value={cost}
              onChange={(e) => setCost(e.target.value)}
              disabled={saving}
            />
          </div>

          <VimdyInput
            type="number"
            min={0}
            label="Stock inicial"
            placeholder="0"
            hint="Si no ingresas stock, comenzará con 0 unidades."
            value={stock}
            onChange={(e) => setStock(e.target.value)}
            disabled={saving}
          />

          {error && (
            <div className="flex items-start gap-2 rounded-vimdy-md border border-vimdy-danger/40 bg-vimdy-danger-bg px-4 py-3 text-vimdy-small text-vimdy-danger">
              <span className="mt-0.5 shrink-0">⚠</span>
              <span>{error}</span>
            </div>
          )}

          <div className="flex flex-col sm:flex-row justify-center gap-3 pt-2">
            <VimdyButton type="submit" disabled={saving || checkingProducts} className="min-w-[200px]">
              {saving ? (
                <span className="flex items-center gap-2">
                  <Loader2 size={18} className="animate-spin" />
                  Guardando...
                </span>
              ) : (
                "Crear producto"
              )}
            </VimdyButton>
            {hasActiveProduct && (
              <VimdyButton
                variant="ghost"
                type="button"
                onClick={() => void handleContinue()}
                disabled={saving || checkingProducts}
              >
                Continuar
              </VimdyButton>
            )}
          </div>
          {!checkingProducts && !hasActiveProduct && (
            <p className="text-center text-vimdy-small text-vimdy-text-secondary">
              Este paso es obligatorio. Necesitas al menos un producto para empezar a vender.
            </p>
          )}
        </form>
      </VimdyCard>
    </div>
  );
}